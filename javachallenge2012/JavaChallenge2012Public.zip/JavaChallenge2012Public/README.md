JavaChallenge2012 version.0.9.1 for public release
=================

# How to play with the user play mode
1. Launch the game
    Execute "java -jar JavaChallenge2012*.jar" 

2. Enter players' names
    Enter player names on a single line separated by a single space.
    e.g.)  If you input "ICPC 2012 Tokyo Java challenge" , 
    "ICPC","2012","Tokyo","Java","challenge" are the players' name.
    Don't input only one player's name , for example "ICPC".
 
3. Choose your veins
    When the game starts, you will need to pick to veins to start with.
    If you left-click, the vein status is displayed.
    If you right-click, the vein coordinates are inputed on the command line.

4. Start playing
    Once the games starts, you can enter commands while it is your turn to play.
    A list of commands is available with the "help" command.

5. Game end
    The game ends when a player has taken all his oponents' veins or when 200 rounds have passed.

# Game Manual
https://docs.google.com/document/d/1tkPcN99Ru_Vd78J3NJkV-wMqLyaxr0YxSv8uA11GEHo/edit

# API Reference
http://javachallenge2012.github.com/JavaChallenge2012/doc/

# How to run
java -jar *.jar

# Tips
* The logs in the textbox are saved in the "log" directory

# Changelog
## from 0.9.0 to 0.9.1 (16th November 2012)
* Improve performance
* Fix trading with players to return money or materials when canceling

## from 0.8.0 to 0.9.0 (15th November 2012)
* Add new feature to skip dead players who have no vein
* Add new feature to limit the maximum numbers of executable commands up to 100 commands in a turn
* Add some new methods in the API
* Improve rendering the game screen to display more information
* Change game parameters and the market trade for aliens to be suitable along with the documents
* Fix typos in the methods and the javadoc
* Fix "bank" command which did not work
