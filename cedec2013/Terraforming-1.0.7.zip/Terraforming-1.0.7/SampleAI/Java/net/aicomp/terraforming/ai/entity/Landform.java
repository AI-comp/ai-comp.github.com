package net.aicomp.terraforming.ai.entity;

public enum Landform {
	Wasteland, Settlement, Base, Hole,
}
