Terraforming for CEDEC 2013
========================

### 必要な環境
- JDK 1.6以上

### 遊び方
- ユーザープレイモード

        java -jar Terraforming-0.5.0.jar


- AIプレイモード

        java -jar Terraforming-0.5.0.jar -a "java -cp SampleAI/Java Main" "java -cp SampleAI/Java Main" "java -cp SampleAI/Java Main"

