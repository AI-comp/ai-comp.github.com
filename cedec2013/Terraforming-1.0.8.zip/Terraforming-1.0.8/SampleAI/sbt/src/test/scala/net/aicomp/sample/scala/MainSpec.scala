package net.aicomp.sample.scala

import org.specs2.mutable.SpecificationWithJUnit

class MainSpec extends SpecificationWithJUnit {
  "Main" should {
    "main" in {
      true must_== true
    }
  }
}
