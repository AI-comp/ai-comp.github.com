Rule book of Terraforming

-QUICK_RULEBOOK.jp.md
-DETAILED_RULEBOOK.jp.md
